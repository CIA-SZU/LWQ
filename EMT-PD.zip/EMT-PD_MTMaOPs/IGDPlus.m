function Score = IGDPlus(PopObj,PF)
% <metric> <min>
% Inverted generational distance

%--------------------------------------------------------------------------
% The copyright of the PlatEMO belongs to the BIMK Group. You are free to
% use the PlatEMO for research purposes. All publications which use this
% platform or any code in the platform should acknowledge the use of
% "PlatEMO" and reference "Ye Tian, Ran Cheng, Xingyi Zhang, and Yaochu
% Jin, PlatEMO: A MATLAB Platform for Evolutionary Multi-Objective
% Optimization, 2016".
%--------------------------------------------------------------------------

% Copyright (c) 2016-2017 BIMK Group
Z=min(PF,[],1);
Znad=max(PF,[],1);
[N,~]=size(PopObj);
PopObj   = (PopObj-repmat(Z,N,1))./(repmat(Znad,N,1)-repmat(Z,N,1));
[N,~]=size(PF);
PF= (PF-repmat(Z,N,1))./(repmat(Znad,N,1)-repmat(Z,N,1));
[n,~]=size(PF);
[popnum,~]=size(PopObj);


% PopObj=1-PopObj;
% PF=1-PF;
for i=1:popnum   
    hh=PF-repmat(PopObj(i,:),n,1);
    hh(hh>0)=0;
    c = sqrt(sum(hh.^2,2));
    FF(i,:)=c;
end
    Distance = min(FF',[],2);
    Score    = mean(Distance);
end