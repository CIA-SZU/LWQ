function [label, model, llh , b] = mixGaussEm(X, init)
% Perform EM algorithm for fitting the Gaussian mixture model.
% Input: 
%   X: d x n data matrix
%   init: k (1 x 1) number of components or label (1 x n, 1<=label(i)<=k) or model structure
% Output:
%   label: 1 x n cluster label
%   model: trained model structure
%   llh: loglikelihood
% Written by Mo Chen (sth4nth@gmail.com).
%% init
% fprintf('EM for Gaussian mixture: running ... \n');
a = [];
b = [];
tol = 1e-6;
maxiter = 30;
llh = -inf(1,maxiter);
R = initialization(X,init);
for iter = 2:maxiter
    [~,label(1,:)] = max(R,[],2);    
    R = R(:,unique(label));           
    model = maximization(X,R);        
    b(1,iter) = model.mu;
    [R, llh(iter)] = expectation(X,model);         
    if abs(llh(iter)-llh(iter-1)) < tol*abs(llh(iter)); break; end;
end
% a = [1:1:maxiter-1];
% mua1 = [];
for i = 2:size(b,2)
    mua1(i-1) = pdist2(b(i),b(i-1));
end
b = mua1;
% b = b(2:500);
% b = log(b);
% c = polyfit(a, b, 2);
% d = polyval(c, a, 1);
% plot(a, d, 'r');
% plot(b);
% hold on;

llh = llh(2:iter);