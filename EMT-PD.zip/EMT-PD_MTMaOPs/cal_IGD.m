function IGD = cal_IGD(data,type,Global)
IGD = 0;
switch(type)
    case 'MaF1_PF'
        MaF1_PF = MaF1('PF',Global,data);
        IGD = IGDPlus(data,MaF1_PF);
        %         [n,~]=size(MaF1_PF);
        %         [popnum,~]=size(data);
        %         for i=1:popnum
        %             hh=repmat(data(i,:),n,1)-MaF1_PF;
        %             hh(hh<0)=0;
        %             c =(sum(hh.^2,2)).^(1/2);
        %             FF(i,:)=c';
        %         end
        %         Distance = min(FF',[],2);
        %         IGD = mean(Distance);
    case 'MaF3_PF'
        %         MaF3_PF = MaF3('PF',Global,data);
        %         Distance = min(pdist2(MaF3_PF,data),[],2);
        %         IGD = mean(Distance);
        MaF3_PF = MaF3('PF',Global,data);
        IGD = IGDPlus(data,MaF3_PF);
        %         [n,~]=size(MaF3_PF);
        %         [popnum,~]=size(data);
        %         for i=1:popnum
        %             hh=repmat(data(i,:),n,1)-MaF3_PF;
        %             hh(hh<0)=0;
        %             c =(sum(hh.^2,2)).^(1/2);
        %             FF(i,:)=c';
        %         end
        %         Distance = min(FF',[],2);
        %         IGD = mean(Distance);
    case 'MaF4_PF'
        %         MaF4_PF = MaF4('PF',Global,data);
        %         Distance = min(pdist2(MaF4_PF,data),[],2);
        %         IGD = mean(Distance);
        MaF4_PF = MaF4('PF',Global,data);
        IGD = IGDPlus(data,MaF4_PF);
        %         [n,~]=size(MaF4_PF);
        %         [popnum,~]=size(data);
        %         for i=1:popnum
        %             hh=repmat(data(i,:),n,1)-MaF4_PF;
        %             hh(hh<0)=0;
        %             c =(sum(hh.^2,2)).^(1/2);
        %             FF(i,:)=c';
        %         end
        %         Distance = min(FF',[],2);
        %         IGD = mean(Distance);
        
    case 'MaF5_PF'
        MaF5_PF = MaF5('PF',Global,data);
        %         Distance = min(pdist2(MaF5_PF,data),[],2);
        %         IGD = mean(Distance);
        IGD = IGDPlus(data,MaF5_PF);
        %         [n,~]=size(MaF5_PF);
        %         [popnum,~]=size(data);
        %         for i=1:popnum
        %             hh=repmat(data(i,:),n,1)-MaF5_PF;
        %             hh(hh<0)=0;
        %             c =(sum(hh.^2,2)).^(1/2);
        %             FF(i,:)=c';
        %         end
        %         Distance = min(FF',[],2);
        %         IGD = mean(Distance);
    case 'MaF6_PF'
        MaF6_PF = MaF6('PF',Global,data);
        %         Distance = min(pdist2(MaF6_PF,data),[],2);
        %         IGD = mean(Distance);
        IGD = IGDPlus(data,MaF6_PF);
        %         [n,~]=size(MaF6_PF);
        %         [popnum,~]=size(data);
        %         for i=1:popnum
        %             hh=repmat(data(i,:),n,1)-MaF6_PF;
        %             hh(hh<0)=0;
        %             c =(sum(hh.^2,2)).^(1/2);
        %             FF(i,:)=c';
        %         end
        %         Distance = min(FF',[],2);
        %         IGD = mean(Distance);
    case 'MaF7_PF'
        MaF7_PF = MaF7('PF',Global,data);
        %         Distance = min(pdist2(MaF7_PF,data),[],2);
        %         IGD = mean(Distance);
        IGD = IGDPlus(data,MaF7_PF);
        %         [n,~]=size(MaF7_PF);
        %         [popnum,~]=size(data);
        %         for i=1:popnum
        %             hh=repmat(data(i,:),n,1)-MaF7_PF;
        %             hh(hh<0)=0;
        %             c =(sum(hh.^2,2)).^(1/2);
        %             FF(i,:)=c';
        %         end
        %         Distance = min(FF',[],2);
        %         IGD = mean(Distance);
end
end