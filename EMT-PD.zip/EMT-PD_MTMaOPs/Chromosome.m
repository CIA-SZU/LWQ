classdef Chromosome
    
    properties
        rnvec;
        objs_T1;
        objs_T2;
        convio;
        skill_factor;
        front;
        CD;
        rank;
        w;
        dominationcount=0;
        dominatedset=[];
        dominatedsetlength=0;
    end
    
    methods
        
        function object=initialize(object,dim)
            object.rnvec=rand(1,dim);
        end
        
        function object=evaluate(object,Task,dim1,dim2,M,Global)
            if object.skill_factor==1
                xtemp=object.rnvec(1:dim1);                
                x=Task.L1+xtemp.*(Task.U1-Task.L1); 
                [object.objs_T1,object.convio]=mo_benchmark(x,Task.type1,M,Global); 
            else
                xtemp=object.rnvec(1:dim2);                
                x=Task.L2+xtemp.*(Task.U2-Task.L2);                
                [object.objs_T2,object.convio]=mo_benchmark(x,Task.type2,M,Global);  
            end            
        end   
        
        function population=reset(population,pop)
            for i=1:pop
                population(i).dominationcount=0;
                population(i).dominatedset=[];
                population(i).dominatedsetlength=0;
            end
        end     
    end    
    
end

