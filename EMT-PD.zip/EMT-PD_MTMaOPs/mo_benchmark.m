function [obj,convio]=mo_benchmark(x,fun,M,Global)

D=length(x);
convio=0;
%% CIHS
% CIHS_task_T1 B1
if strcmp(fun,'MaF1_PF')
    obj = MaF1('value',Global,x,M);
end
if strcmp(fun,'MaF3_PF')
    obj = MaF3('value',Global,x,M);
end
if strcmp(fun,'MaF4_PF')
    obj = MaF4('value',Global,x,M);
end
if strcmp(fun,'MaF5_PF')
    obj = MaF5('value',Global,x,M);
end
if strcmp(fun,'MaF6_PF')
    obj = MaF6('value',Global,x,M);
end
if strcmp(fun,'MaF7_PF')
    obj = MaF7('value',Global,x,M);
end
end