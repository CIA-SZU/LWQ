function Tasks = benchmark(index,M)
%BENCHMARK function
%   Input
%   - index: the index number of problem set
%   Output:
%   - Tasks: benchmark problem set
switch(index)
    case 1  %HS
        Tasks.f1='MaFHS_task_T1';
        % Assigning upper and lower bounds of search space of task 1
        Tasks.dims1 = M+9;
        Tasks.L1=zeros(1,Tasks.dims1);
        Tasks.U1=ones(1,Tasks.dims1);
        Tasks.type1 = 'MaF3_PF';
        
        Tasks.f2='MaFHS_task_T2';
        % Assigning upper and lower bounds of search space of task 2
        Tasks.dims2 = M+9;
        Tasks.L2=zeros(1,Tasks.dims2);
        Tasks.U2=ones(1,Tasks.dims2);
        Tasks.type2 = 'MaF4_PF';
    case 2  %HS
        Tasks.f1='MaFHS_task_T1';
        % Assigning upper and lower bounds of search space of task 2
        Tasks.dims1 = M+9;
        Tasks.L1=zeros(1,Tasks.dims1);
        Tasks.U1=ones(1,Tasks.dims1);
        Tasks.type1 = 'MaF4_PF';
        
        Tasks.f2='MaFHS_task_T2';
        % Assigning upper and lower bounds of search space of task 2
        Tasks.dims2 = M+9;
        Tasks.L2=zeros(1,Tasks.dims2);
        Tasks.U2=ones(1,Tasks.dims2);
        Tasks.type2 = 'MaF6_PF';
    case 3 %MS
%         Tasks.f1='MaFLS_task_T1';
%         % Assigning upper and lower bounds of search space of task 1
%         Tasks.dims1 = M+9;
%         Tasks.L1=zeros(1,Tasks.dims1);
%         Tasks.U1=ones(1,Tasks.dims1);
%         Tasks.type1 = 'MaF1_PF';
        Tasks.f1='MaFLS_task_T2';
        % Assigning upper and lower bounds of search space of task 2
        Tasks.dims1 = M+9;
        Tasks.L1=zeros(1,Tasks.dims1);
        Tasks.U1=ones(1,Tasks.dims1);
        Tasks.type1 = 'MaF4_PF';
        
        Tasks.f2='MaFLS_task_T2';
        % Assigning upper and lower bounds of search space of task 2
        Tasks.dims2 = M+9;
        Tasks.L2=zeros(1,Tasks.dims2);
        Tasks.U2=ones(1,Tasks.dims2);
        Tasks.type2 = 'MaF5_PF';
    case 4 %MS
        Tasks.f1='MaFLS_task_T1';
        % Assigning upper and lower bounds of search space of task 1
        Tasks.dims1 = M+9;
        Tasks.L1=zeros(1,Tasks.dims1);
        Tasks.U1=ones(1,Tasks.dims1);
        Tasks.type1 = 'MaF5_PF';
        
        Tasks.f2='MaFLS_task_T2';
        % Assigning upper and lower bounds of search space of task 2
        Tasks.dims2 = M+9;
        Tasks.L2=zeros(1,Tasks.dims2);
        Tasks.U2=ones(1,Tasks.dims2);
        Tasks.type2 = 'MaF6_PF';
    case 5 %LS
        Tasks.f1='MaFLS_task_T1';
        % Assigning upper and lower bounds of search space of task 1
        Tasks.dims1 = M+9;
        Tasks.L1=zeros(1,Tasks.dims1);
        Tasks.U1=ones(1,Tasks.dims1);
        Tasks.type1 = 'MaF4_PF';
        
        Tasks.f2='MaFLS_task_T2';
        % Assigning upper and lower bounds of search space of task 2
        Tasks.dims2 = M+9;
        Tasks.L2=zeros(1,Tasks.dims2);
        Tasks.U2=ones(1,Tasks.dims2);
        Tasks.type2 = 'MaF5_PF';
    case 6 %LS
        Tasks.f1='MaFLS_task_T1';
        % Assigning upper and lower bounds of search space of task 1
        Tasks.dims1 = M+9;
        Tasks.L1=zeros(1,Tasks.dims1);
        Tasks.U1=ones(1,Tasks.dims1);
        Tasks.type1 = 'MaF3_PF';
        
        Tasks.f2='MaFLS_task_T2';
        % Assigning upper and lower bounds of search space of task 2
        Tasks.dims2 = M+9;
        Tasks.L2=zeros(1,Tasks.dims2);
        Tasks.U2=ones(1,Tasks.dims2);
        Tasks.type2 = 'MaF6_PF';
end