function [child,mu1,mu2,b] = Strantegy(population,mu1,mu2,generation)
pop_t1 = population([population.skill_factor]==1);
pop_t2 = population([population.skill_factor]==2);
size_t1 = size(pop_t1(1).rnvec,2);
size_t2 = size(pop_t2(1).rnvec,2);
size_p1 = size(pop_t1,2);
size_p2 = size(pop_t2,2);
size_pop = max(size_t1,size_t2);
simple_num = floor(size(pop_t1,2)*0.4);
b = [];
for i = 1:simple_num
    OP_t1(i) = Chromosome();
    OP_t2(i) = Chromosome();
end
for i = 1:size(pop_t1,2)
    if pop_t1(i).rank <= simple_num
        OP_t1(pop_t1(i).rank) = pop_t1(i);
    end
    
    if pop_t2(i).rank <= simple_num
        OP_t2(pop_t2(i).rank) = pop_t2(i);
    end
end

P = zeros(size_pop,simple_num);
Q = zeros(size_pop,simple_num);
A_t1 = zeros(size_pop,size_pop);
A_t2 = zeros(size_pop,size_pop);

for i = 1:simple_num
    P(1:size_pop,i) =  OP_t1(i).rnvec;
    Q(1:size_pop,i) =  OP_t2(i).rnvec;
end

for i = 1:size_t1
    a = P(i,1:simple_num);
    c = Q(i,1:simple_num);
    for j = 1:size_t1
        b = P(j,1:simple_num);
        d = Q(j,1:simple_num);
        
        e = cov(a,b);
        A_t1(i,j)  = e(1,2);
        
        f = cov(c,d);
        A_t2(i,j) = f(1,2);
    end
end
for i = 1:size(P,1)
    X = P(i,:);
    [label, model, llh , b1] = mixGaussEm(X, 1);
    avg_P(i,1) = model.mu;
    var_P(i,1) = model.Sigma;
    
    
    X = Q(i,:);
    [label, model, llh , b2] = mixGaussEm(X, 1);
    avg_Q(i,1) = model.mu;
    var_Q(i,1) = model.Sigma;
end


mu1(generation,:) = avg_P;
mu2(generation,:) = avg_Q;

A = inv(inv(A_t1) + inv(A_t2));
avg_n = A*(inv(A_t1)*avg_P + inv(A_t2)*avg_Q);

max_n = max(avg_n);
min_n = min(avg_n);

avg_n = (avg_n-min_n)/(max_n-min_n);

w1 = avg_P - avg_n;
w2 = avg_Q - avg_n;

t1_var = cov(P,P);
t2_var = cov(Q,Q);
t_var = cov(P,Q);
V = 0.01;
for i = 1:size_p1
    a = randperm(simple_num,1);
    b = randperm(simple_num,1);
    child(i) = Chromosome();
    child(i).skill_factor = 1;
%     child(i).rnvec = w1'.*OP_t1(a).rnvec + (w1+0.001*randn(1,size_t1)'/(1-t1_var+t2_var)).*OP_t1(a).rnvec;
    child(i).rnvec = OP_t1(a).rnvec + w1'.*(w1'-OP_t2(b).rnvec);
    estimate_1 = child(i).rnvec(child(i).rnvec>1);
    estimate_2 = child(i).rnvec(child(i).rnvec<0);
    if size(estimate_1,2)>0 || size(estimate_2,2)>0
        d = [];
        c = child(i).rnvec;
        for k = 1:size(c,2)
            d(k) = (-log(1/c(k)-1)+100)/200;
            d(k) = real(d(k));
        end
        d(1) = rand(1);
        r=0+0.1*randn(1,1);
        child(i).rnvec = d + r; 
    end
    child(i).rnvec(child(i).rnvec>1) = 1;
    child(i).rnvec(child(i).rnvec<0) = 0;
end
for i = size_p1+1:size_p1 + size_p2
    a = randperm(simple_num,1);
    b = randperm(simple_num,1);
    child(i) = Chromosome();
    child(i).skill_factor = 2;
    child(i).rnvec = w2'.*OP_t1(a).rnvec + (1-w2)'.*OP_t2(b).rnvec;
    child(i).rnvec = OP_t1(a).rnvec + w2'.*(w2'-OP_t2(b).rnvec);
    estimate_1 = child(i).rnvec(child(i).rnvec>1);
    estimate_2 = child(i).rnvec(child(i).rnvec<0);
    if size(estimate_1,2)>0 || size(estimate_2,2)>0
        d = [];
        c = child(i).rnvec;
        for k = 1:size(c,2)
            d(k) = (-log(1/c(k)-1)+100)/200;
            d(k) = real(d(k));
        end
        d(1) = rand(1);
        r=0+0.1*randn(1,1);
        child(i).rnvec = d + r; 
    end
    child(i).rnvec(child(i).rnvec>1) = 1;
    child(i).rnvec(child(i).rnvec<0) = 0;
end
end