% This trial version of the Multi-Objective Multifactorial Evolutionary Algorithm (MO-MFEA: which is based on NSGA-II) has been
% developed to handle only two "continuous" multiobjective problems (or tasks) at a time.
% Each problem may comprise upto three objective functions.
% Generalization to many-tasking can be done based on this framework.
function [data_MOMFEA,scob]=MOMFEA(Task,pop1,pop2,rmp,gen,muc,mum,pc,reps,index,Global1,Global2,M,scob)
tic
G = 1;
warning off;
pop=pop1+pop2;
if mod(pop,2)~=0
    pop=pop+1;
    pop2=pop2+1;
end
dim1=length(Task.L1);
dim2=length(Task.L2);
dim=max([dim1,dim2]);

mu1 = [];
mu2 = [];

for rep = 1:reps
    store = [];
    for i=1:pop
        population(i)=Chromosome;
        population(i)=initialize(population(i),dim);
        if i<=pop1
            population(i).skill_factor=1;
        else
            population(i).skill_factor=2;
        end
    end
    if index == 3 || index == 4
        S = zeros(1,dim2);
        S(end) = 0.00005;
        S(end-1) = 0.00005;
        for i=1:pop
            or_population = population(i);
            if population(i).skill_factor == 1
                population(i)=evaluate(population(i),Task,dim1,dim2,M,Global1);
            elseif population(i).skill_factor == 2
                population(i).rnvec = population(i).rnvec - S;
                population(i)=evaluate(population(i),Task,dim1,dim2,M,Global2);
            end
            population(i).rnvec = or_population.rnvec;
        end
    else
        for i=1:pop
            if population(i).skill_factor == 1
                population(i)=evaluate(population(i),Task,dim1,dim2,M,Global1);
            elseif population(i).skill_factor == 2
                population(i)=evaluate(population(i),Task,dim1,dim2,M,Global2);
            end
        end
    end
    population_T1=population([population.skill_factor]==1);
    population_T2=population([population.skill_factor]==2);
    no_of_objs_T1 = length(population_T1(1).objs_T1);
    no_of_objs_T2 = length(population_T2(1).objs_T2);
    [population_T1,frontnumbers]=SolutionComparison.nondominatedsort(population_T1,pop1,no_of_objs_T1);
    [population_T1,~]=SolutionComparison.diversity(population_T1,frontnumbers,pop1,no_of_objs_T1);
    [population_T2,frontnumbers]=SolutionComparison.nondominatedsort(population_T2,pop2,no_of_objs_T2);
    [population_T2,~]=SolutionComparison.diversity(population_T2,frontnumbers,pop2,no_of_objs_T2);
    population(1:pop1) = population_T1;
    population(pop1+1:pop) = population_T2;
    
    for generation=1:gen
        rndlist=randperm(pop);
        population=population(rndlist);
        for i = 1:pop % Performing binary tournament selection to create parent pool
            parent(i)=Chromosome();
            p1=1+round(rand(1)*(pop-1));
            p2=1+round(rand(1)*(pop-1));
            if population(p1).rank < population(p2).rank
                parent(i).rnvec=population(p1).rnvec;
                parent(i).skill_factor=population(p1).skill_factor;
            elseif population(p1).rank == population(p2).rank
                if rand(1) <= 0.5
                    parent(i).rnvec=population(p1).rnvec;
                    parent(i).skill_factor=population(p1).skill_factor;
                else
                    parent(i).rnvec=population(p2).rnvec;
                    parent(i).skill_factor=population(p2).skill_factor;
                end
            else
                parent(i).rnvec=population(p2).rnvec;
                parent(i).skill_factor=population(p2).skill_factor;
            end
        end
        count = 1;
        if mod(generation,G) ~= 0
            for i=1:2:pop-1 % Create offspring population via mutation and crossover
                child(count)=Chromosome;
                child(count+1)=Chromosome;
                p1=i;
                p2=i+1;
                if parent(p1).skill_factor==parent(p2).skill_factor
                    [child(count).rnvec,child(count+1).rnvec]=Evolve.crossover(parent(p1).rnvec,parent(p2).rnvec,muc,dim,pc);
                    child(count).rnvec = Evolve.mutate(child(count).rnvec,mum,dim,1/dim);
                    child(count+1).rnvec=Evolve.mutate(child(count+1).rnvec,mum,dim,1/dim);
                    child(count).skill_factor=parent(p1).skill_factor;
                    child(count+1).skill_factor=parent(p2).skill_factor;
                else
                    if rand(1)<rmp
                        [child(count).rnvec,child(count+1).rnvec]= Evolve.crossover(parent(p1).rnvec,parent(p2).rnvec,muc,dim,pc);
                        child(count).rnvec = Evolve.mutate(child(count).rnvec,mum,dim,1/dim);
                        child(count+1).rnvec=Evolve.mutate(child(count+1).rnvec,mum,dim,1/dim);
                        child(count).skill_factor=round(rand(1))+1;
                        child(count+1).skill_factor=round(rand(1))+1;
                    else
                        child(count).rnvec = Evolve.mutate(parent(p1).rnvec,mum,dim,1);
                        child(count+1).rnvec=Evolve.mutate(parent(p2).rnvec,mum,dim,1);
                        child(count).skill_factor=parent(p1).skill_factor;
                        child(count+1).skill_factor=parent(p2).skill_factor;
                    end
                end
                count=count+2;
            end
        else
            [child,mu1,mu2,b] = Strategy(population,mu1,mu2,generation);
            for i = 1:size(child)
                child(i).rnvec = Evolve.mutate(child(i).rnvec,mum,dim,1);
            end
            
        end
        scob(end+1,1:29) = b(1,:);
        scob(end+1,1:29) = b(1,:);
        if index == 3 || index == 4
            S = zeros(1,dim2);
            S(end) = 0.05;
            S(end-1) = 0.05;
            for i=1:pop
                or_population = child(i);
                if child(i).skill_factor == 1
                    child(i)=evaluate(child(i),Task,dim1,dim2,M,Global1);
                elseif child(i).skill_factor == 2
                    child(i).rnvec = child(i).rnvec - S;
                    child(i)=evaluate(child(i),Task,dim1,dim2,M,Global2);
                end
                child(i).rnvec = or_population.rnvec;
            end
        else
            for i=1:pop
                if child(i).skill_factor == 1
                    child(i)=evaluate(child(i),Task,dim1,dim2,M,Global1);
                elseif child(i).skill_factor == 2
                    child(i)=evaluate(child(i),Task,dim1,dim2,M,Global2);
                end
            end
        end
        
        %         population=reset(population,pop);
        %         intpopulation(1:pop)=population;
        %         intpopulation(pop+1:2*pop)=child;
        %         intpopulation_T1=intpopulation([intpopulation.skill_factor]==1);
        %         intpopulation_T2=intpopulation([intpopulation.skill_factor]==2);
        %         T1_pop=length(intpopulation_T1);
        %         T2_pop=length(intpopulation_T2);
        
        
        
        %         pop_objs_T1=[];
        %         pop_objs_T2=[];
        %         for i=1:T1_pop
        %             pop_objs_T1(i,:) = intpopulation_T1(i).objs_T1;
        %         end
        %         [frontnumbers, FrontNO1,~] = NDSort(pop_objs_T1,inf);
        %         for i=1:T1_pop
        %             intpopulation_T1(i).front = FrontNO1(i);
        %         end
        %         [intpopulation_T1,~]=SolutionComparison.diversity(intpopulation_T1,frontnumbers,T1_pop,no_of_objs_T1);
        %
        %         for i=1:T2_pop
        %             pop_objs_T2(i,:) = intpopulation_T2(i).objs_T2;
        %         end
        %         [frontnumbers, FrontNO2,~] = NDSort(pop_objs_T2,inf);
        %         for i=1:T2_pop
        %             intpopulation_T2(i).front = FrontNO2(i);
        %         end
        %         [intpopulation_T2,~]=SolutionComparison.diversity(intpopulation_T2,frontnumbers,T2_pop,no_of_objs_T2);
        %         population(1:pop1) = intpopulation_T1(1:pop1);
        %         population(pop1+1:pop) = intpopulation_T2(1:pop2);
        %
        %         Child_selection = struct;
        %
        %         for i = 1:size(intpopulation_T1,2)
        %             Child_selection_T1(i) = INDIVIDUAL(intpopulation_T1(i).rnvec,0,intpopulation_T1(i).objs_T1);
        %         end
        %         [Z,~] = UniformPoint(pop1,Global2.M);
        %         Zmin = [];
        %         Zmin = min([Zmin;Child_selection_T1(all(Child_selection_T1.cons<=0,2)).objs],[],1);
        %         intpopulation_T1 = EnvironmentalSelection(Child_selection_T1,pop1,Z,Zmin);
        %
        %
        %         for i = 1:size(intpopulation_T2,2)
        %             Child_selection_T2(i) = INDIVIDUAL(intpopulation_T2(i).rnvec,0,intpopulation_T2(i).objs_T2);
        %         end
        %         [Z,~] = UniformPoint(pop2,Global1.M);
        %         Zmin = [];
        %         Zmin = min([Zmin;Child_selection_T2(all(Child_selection_T2.cons<=0,2)).objs],[],1);
        %         intpopulation_T2 = EnvironmentalSelection(Child_selection_T2,pop1,Z,Zmin);
        %
        %         for i = 1:pop1
        %             population(i).rnvec = intpopulation_T1(i).dec;
        %             population(i).objs_T1 = intpopulation_T1(i).obj;
        %             population(i).objs_T2 = [];
        %             population(i).skill_factor = 1;
        %             population(i).rank = i;
        %         end
        %
        %         for i = pop1+1:pop
        %             population(i).rnvec = intpopulation_T2(i-pop1).dec;
        %             population(i).objs_T2 = intpopulation_T2(i-pop1).obj;
        %             population(i).objs_T1 = [];
        %             population(i).skill_factor = 2;
        %             population(i).rank = i-pop1;
        %         end
        
        intpopulation(1:pop)=population;
        intpopulation(pop+1:2*pop)=child;
        intpopulation_T1=intpopulation([intpopulation.skill_factor]==1);
        intpopulation_T2=intpopulation([intpopulation.skill_factor]==2);
        T1_pop=length(intpopulation_T1);
        T2_pop=length(intpopulation_T2);
        pop_objs_T1=[];
        pop_objs_T2=[];
        for i=1:T1_pop
            pop_objs_T1(i,:) = intpopulation_T1(i).objs_T1;
        end
        [frontnumbers, FrontNO1,~] = NDSort(pop_objs_T1,inf);
        for i=1:T1_pop
            intpopulation_T1(i).front = FrontNO1(i);
        end
        [intpopulation_T1,~]=SolutionComparison.diversity(intpopulation_T1,frontnumbers,T1_pop,no_of_objs_T1);
        for i=1:T2_pop
            pop_objs_T2(i,:) = intpopulation_T2(i).objs_T2;
        end
        [frontnumbers, FrontNO2,~] = NDSort(pop_objs_T2,inf);
        for i=1:T2_pop
            intpopulation_T2(i).front = FrontNO2(i);
        end
        [intpopulation_T2,~]=SolutionComparison.diversity(intpopulation_T2,frontnumbers,T2_pop,no_of_objs_T2);
        population(1:pop1) = intpopulation_T1(1:pop1);
        population(pop1+1:pop) = intpopulation_T2(1:pop2);
        T1_data = vec2mat([population(1:pop1).objs_T1],M);
        T2_data = vec2mat([population(pop1+1:pop).objs_T2],M);
        store(1,generation)=cal_IGD(T1_data,Task.type1,Global1);
        store(2,generation)=cal_IGD(T2_data,Task.type2,Global2);
        store(1,generation) = min(store(1,:));
        store(2,generation) = min(store(2,:));
        disp(['Index = ',num2str(index),'   ', 'Generation = ',num2str(generation),'   ','MOMFEA IGD = ', num2str(store(1,generation)),'  ', num2str(store(2,generation))]);
        %         disp(['Index = ',num2str(index),'  ','rep=',num2str(rep),'  ', 'Generation = ',num2str(generation)]);
    end
    IGD(1,rep) = min(store(1,:));
    IGD(2,rep) = min(store(2,:));
end
filename = ['GaussIGD',num2str(index)];
save(filename,'store');
data_MOMFEA.wall_clock_time = toc;
data_MOMFEA.IGD = IGD;
end