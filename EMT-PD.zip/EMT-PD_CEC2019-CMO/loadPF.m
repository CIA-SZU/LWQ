%% loadPF: ������Ӧ��PFǰ�زο�ֵ
function [PF1 , PF2] = loadPF(benchMark)
switch benchMark
    case 1
        load pf/F1.pf
        load pf/F2.pf
        PF1 = F1;
        PF2 = F2;
    case 2
        load pf/F1.pf
        load pf/F7.pf
        PF1 = F1;
        PF2 = F7;
    case 3
        load pf/F4.pf
        load pf/F2.pf
        PF1 = F2;
        PF2 = F4;
    case 4
        load pf/F9.pf
        load pf/F2.pf
        PF1 = F2;
        PF2 = F9;
    case 5
        load pf/F3.pf
        load pf/F6.pf
        PF1 = F3;
        PF2 = F6;
    case 6
        load pf/F3.pf
        load pf/F9.pf
        PF1 = F3;
        PF2 = F9;
    case 7
        load pf/F4.pf
        load pf/F5.pf
        PF1 = F4;
        PF2 = F5;
    case 8
        load pf/F5.pf
        load pf/F7.pf
        PF1 = F5;
        PF2 = F7;
    case 9
        load pf/F6.pf
        load pf/F9.pf
        PF1 = F6;
        PF2 = F9;
    case 10
        load pf/F7.pf
        load pf/F8.pf
        PF1 = F7;
        PF2 = F8;
end
end
