function [fitness] = LZ09_F8(numOfObjective , numOfVariable ,child)
	%input child:һ������
	ptype = 21;
	dtype = 4;
	ltype = 21;
	dim = numOfVariable;
	LZ09_F8 = LZ09(dim , numOfObjective , ltype , dtype , ptype);
	fitness= objectiveFunction(LZ09_F8 , child);

end