function fitness = LZ09_F2( numOfObjective , numOfVariable , child )
ptype = 21;
dtype = 1;
ltype = 22;
dim = numOfVariable;
numOfObjective = numOfObjective;
lowerLimit = 0;
upperLimit = 1;
LZ09_F2 = LZ09(dim , numOfObjective , ltype , dtype , ptype);
fitness = objectiveFunction(LZ09_F2 , child);

end

