function [fitness] = LZ09_F6(numOfObjective , numOfVariable ,child)
	%input child:һ������
	ptype = 31;
	dtype = 1;
	ltype = 32;
	dim = numOfVariable;
	LZ09_F6 = LZ09(dim , numOfObjective , ltype , dtype , ptype);
	fitness = objectiveFunction(LZ09_F6 , child);

end