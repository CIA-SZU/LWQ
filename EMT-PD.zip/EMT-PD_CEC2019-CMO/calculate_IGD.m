function [value1,value2]=calculate_IGD(PF1,PF2,T1_data,T2_data)
Distance = min(pdist2(PF1,T1_data),[],2);
value1 = mean(Distance);
Distance = min(pdist2(PF2,T2_data),[],2);
value2 = mean(Distance);
end