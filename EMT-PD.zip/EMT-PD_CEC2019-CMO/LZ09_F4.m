function [fitness] = LZ09_F4(numOfObjective , numOfVariable ,child)
	%input child:һ������
	ptype = 21;
	dtype = 1;
	ltype = 24;
	dim = numOfVariable;
	LZ09_F4 = LZ09(dim , numOfObjective , ltype , dtype , ptype);
	fitness = objectiveFunction(LZ09_F4 , child);

end