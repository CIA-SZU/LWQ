function [child] = Strantegy(population,G)
pop1 = population([population.skill_factor]==1);
pop2 = population([population.skill_factor]==2);
N = size(pop1,2);
dim1 = size(pop1(1).rnvec,2);
dim2 = size(pop2(1).rnvec,2);
dim = max(dim1,dim2);
pop1_size = size(pop1,2);
pop2_size = size(pop2,2);
for i = 1:N
    OP_t1(i) = Chromosome();
    OP_t2(i) = Chromosome();
end

for i = 1:N
    OP_t1(pop1(i).rank) = pop1(i);
    OP_t2(pop2(i).rank) = pop2(i);
end

P = zeros(dim,N);
Q = zeros(dim,N);
A_t1 = zeros(dim,dim);
A_t2 = zeros(dim,dim);

for i = 1:N
    P(1:dim,i) =  OP_t1(i).rnvec;
    Q(1:dim,i) =  OP_t2(i).rnvec;
end

avg_P = zeros(dim,1);
avg_Q = zeros(dim,1);

for i = 1:dim
    X = P(i,:);
    [~, model, ~] = mixGaussEm(X, 1);
    avg_P(i,1) = model.mu;
    
    X = Q(i,:);
    [~, model, ~] = mixGaussEm(X, 1);
    avg_Q(i,1) = model.mu;
end
avg_n = (avg_P + avg_Q)/2;
SF = 0.1*ones(1,dim);
for i = 1:pop1_size
    child(i) = Chromosome();
    child(i).skill_factor = 1;
    a = OP_t1(i).rnvec;
    e1 = sum((avg_P-OP_t1(i).rnvec').^2).^0.5;
    e2 = sum((avg_P-avg_n).^2).^0.5;
    v =  SF*(e1+e2)/dim.*rand(1,dim);
    child(i).rnvec = OP_t1(i).rnvec + (e1/(e1+e2))*(avg_n' - OP_t1(i).rnvec) + v;
end
for i = 1:pop2_size
    child(i+N) = Chromosome();
    child(i+N).skill_factor = 2;
    Q = randn(1,dim);
    e1 = sum((avg_P-OP_t2(i).rnvec').^2).^0.5;
    e2 = sum((avg_P-avg_n).^2).^0.5;
    a = e1/(e1+e2);
    v =  SF.*(e1+e2)/dim.*rand(1,dim);
    child(i+N).rnvec = OP_t2(i).rnvec + (e1/(e1+e2))*(avg_n' - OP_t2(i).rnvec) + v;  
end

for i = 1:pop1_size+pop2_size
    child(i).rnvec(child(i).rnvec>1) = 1;
    child(i).rnvec(child(i).rnvec<0) = 0;
end