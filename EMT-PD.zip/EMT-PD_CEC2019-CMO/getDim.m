%% getDim:nction description
function [dim1 , dim2] = getDim(benchMark)
	switch benchMark
	case {1,2,10}
		dim1 = 10;
		dim2 = 10;
	case {3,4,6,7}
		dim1 = 30;
		dim2 = 30;
	case 9
		dim1 = 10;
		dim2 = 30;
	case {5,8}
		dim1 = 30;
		dim2 = 10;
	end
end
