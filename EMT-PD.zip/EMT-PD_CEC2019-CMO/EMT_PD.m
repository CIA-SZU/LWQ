clear all;
beep off;
warning off;
rmp = 0.3; % Random mating probability
gen = 1000; % Maximum Number of generations
muc = 20; % Distribution Index of SBX crossover operator
mum = 20; % Distribution Index of Polynomial Mutation operator
pc = 0.3; % Probability that certain pair of variables are swapped (uniform crossover-like) during SBX crossover. Change to prob_swap = 0.5 for enhanced global search at the cost of high chromosome disruption.
pop1 = 100; % Population size for task 1
pop2 = 100; % Population size for task 2
reps = 1;
for index = 2:2
    [f1 ,f2,L1,U1,L2,U2,pop1,pop2,PF1,PF2 ] = Tasks(index);
    [dim1 , dim2] = getDim(index);
    [data_MOMFEA(index)] =  MOMFEA...
        (pop1,pop2,dim1,dim2,rmp,gen,muc,mum,index,reps,pc,index);
end
save('pMFEA_MOMFEA_B10','data_MOMFEA');