function [data_MOMFEA]=MOMFEA(pop1,pop2,dim1,dim2,rmp,gen,muc,mum,benchMark_num,reps,pc,index)

pop=pop1+pop2;
if mod(pop,2)~=0
    pop=pop+1;
    pop2=pop2+1;
end
[F1,F2] = loadPF(benchMark_num);
store=[];
dim = max(dim1,dim2);
for rep = 1:reps
    run = rep;
    store = [];
    for i=1:pop
        population(i)=Chromosome;
        population(i)=initialize(population(i),dim);
        if i<=pop1
            population(i).skill_factor=1;
        else
            population(i).skill_factor=2;
        end
    end
    child1 = population([population.skill_factor]==1);
    child2 = population([population.skill_factor]==2);
    [child1 , child2] = evaluate(child1, child2 , benchMark_num);
    population(1:100) = child1;
    population(101:200) = child2;
    
    population_T1=population([population.skill_factor]==1);
    population_T2=population([population.skill_factor]==2);
    no_of_objs_T1 = length(population_T1(1).objs_T1);
    no_of_objs_T2 = length(population_T2(1).objs_T2);
    [population_T1,frontnumbers]=SolutionComparison.nondominatedsort(population_T1,pop1,no_of_objs_T1);
    [population_T1,~]=SolutionComparison.diversity(population_T1,frontnumbers,pop1,no_of_objs_T1);
    [population_T2,frontnumbers]=SolutionComparison.nondominatedsort(population_T2,pop2,no_of_objs_T2);
    [population_T2,~]=SolutionComparison.diversity(population_T2,frontnumbers,pop2,no_of_objs_T2);
    population(1:pop1) = population_T1;
    population(pop1+1:end) = population_T2;
    G = 2;
    for generation=1:gen
        for i = 1:pop
            parent(i)=Chromosome();
            p1 = randi([1,200],1);
            p2 = randi([1,200],1);
            if population(p1).rank <= population(p2).rank
                parent(i).rnvec = population(p1).rnvec;
                parent(i).skill_factor = population(p1).skill_factor;
            else
                parent(i).rnvec = population(p2).rnvec;
                parent(i).skill_factor = population(p2).skill_factor;
            end
        end
        if mod(generation,G) ~= 0
            count=1;
            for i=1:2:pop-1
                child(count)=Chromosome;
                child(count+1)=Chromosome;
                p1=i;
                p2=i+1;
                if parent(p1).skill_factor==parent(p2).skill_factor
                    [child(count).rnvec,child(count+1).rnvec]=Evolve.crossover(parent(p1).rnvec,parent(p2).rnvec,muc,dim,pc);
                    child(count).rnvec = Evolve.mutate(child(count).rnvec,mum,dim,1/dim);
                    child(count+1).rnvec=Evolve.mutate(child(count+1).rnvec,mum,dim,1/dim);
                    child(count).skill_factor=parent(p1).skill_factor;
                    child(count+1).skill_factor=parent(p2).skill_factor;
                else
                    if rand(1)<rmp
                        [child(count).rnvec,child(count+1).rnvec]= Evolve.crossover(parent(p1).rnvec,parent(p2).rnvec,muc,dim,pc);
                        child(count).rnvec = Evolve.mutate(child(count).rnvec,mum,dim,1/dim);
                        child(count+1).rnvec=Evolve.mutate(child(count+1).rnvec,mum,dim,1/dim);
                        child(count).skill_factor=round(rand(1))+1;
                        child(count+1).skill_factor=round(rand(1))+1;
                    else
                        child(count).rnvec = Evolve.mutate(parent(p1).rnvec,mum,dim,1);
                        child(count+1).rnvec=Evolve.mutate(parent(p2).rnvec,mum,dim,1);
                        child(count).skill_factor=parent(p1).skill_factor;
                        child(count+1).skill_factor=parent(p2).skill_factor;
                    end
                end
                count=count+2;
            end
        else
            [child] = Strategy(population);
            for i = 1:size(child)
                child(i).rnvec = Evolve.mutate(child(i).rnvec,mum,dim,1);
            end
        end
        
        
        child1 = child([child.skill_factor]==1);
        child2 = child([child.skill_factor]==2);
        [child1 , child2] = evaluate(child1, child2 , benchMark_num);
        child = [child1 , child2];
        population=reset(population,pop);
        intpopulation(1:pop)=population;
        intpopulation(pop+1:2*pop)=child;
        intpopulation_T1=intpopulation([intpopulation.skill_factor]==1);
        intpopulation_T2=intpopulation([intpopulation.skill_factor]==2);
        T1_pop=length(intpopulation_T1);
        T2_pop=length(intpopulation_T2);
        for i=1:T1_pop
            popobj1(i,:) = intpopulation_T1(i).objs_T1;
        end
        [front1, FrontNO1,~] = NDSort(popobj1,inf);
        for i=1:T1_pop
            intpopulation_T1(i).front = FrontNO1(i);
        end
        
        for i=1:T2_pop
            popobj2(i,:) = intpopulation_T2(i).objs_T2;
        end
        [ front2, FrontNO2,~] = NDSort(popobj2,inf);
        for i=1:T2_pop
            intpopulation_T2(i).front = FrontNO2(i);
        end
        [intpopulation_T1,~]=SolutionComparison.diversity(intpopulation_T1,front1,T1_pop,no_of_objs_T1);
        [intpopulation_T2,~]=SolutionComparison.diversity(intpopulation_T2,front2,T2_pop,no_of_objs_T2);
        population(1:pop1) = intpopulation_T1(1:pop1);
        population(pop1+1:pop) = intpopulation_T2(1:pop2);
        
        if benchMark_num == 5
            T1_data = vec2mat([population(1:pop1).objs_T1],2);
            T2_data = vec2mat([population(pop1+1:pop).objs_T2],3);
        elseif benchMark_num == 9
            T1_data = vec2mat([population(1:pop1).objs_T1],3);
            T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
        else
            T1_data = vec2mat([population(1:pop1).objs_T1],2);
            T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
        end
        
        [value1 , value2] = calculate_IGD( F1,F2, T1_data, T2_data);
        store(1,generation) = value1;
        store(2,generation) = value2;
        store(1,generation)=min(store(1,:));
        store(2,generation)=min(store(2,:));
        disp(['Index=',num2str(benchMark_num),'   ','Rep=',num2str(rep),'   ','Generation:',num2str(generation),'  ',num2str(store(1,generation)),'  ',num2str(store(2,generation))]);
        popobj1=[];
        popobj2=[];
        
    end
    IGD(1,rep) = store(1,gen);
    IGD(2,rep) = store(2,gen);
end
data_MOMFEA.wall_clock_time = toc;
data_MOMFEA.IGD = store;
end