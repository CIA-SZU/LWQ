function [data_MOMFEA,IGD,record_IGD,result_t1,result_t2]=MOMFEA(Task,pop1,pop2,rmp,gen,muc,mum,pc,reps,index,result_t1,result_t2)
tic
warning off;

pop=pop1+pop2;
if mod(pop,2)~=0
    pop=pop+1;
    pop2=pop2+1;
end
dim1=length(Task.L1);
dim2=length(Task.L2);
dim=max([dim1,dim2]);
G = 5;
for rep = 1:reps
    store = [];
    for i=1:pop
        population(i)=Chromosome;
        population(i)=initialize(population(i),dim);
        if i<=pop1
            population(i).skill_factor=1;
        else
            population(i).skill_factor=2;
        end
    end
    for i=1:pop
        population(i)=evaluate(population(i),Task,dim1,dim2);
    end
    population_T1=population([population.skill_factor]==1);
    population_T2=population([population.skill_factor]==2);
    no_of_objs_T1 = length(population_T1(1).objs_T1);
    no_of_objs_T2 = length(population_T2(1).objs_T2);
    [population_T1,frontnumbers]=SolutionComparison.nondominatedsort(population_T1,pop1,no_of_objs_T1);
    [population_T1,~]=SolutionComparison.diversity(population_T1,frontnumbers,pop1,no_of_objs_T1);
    [population_T2,frontnumbers]=SolutionComparison.nondominatedsort(population_T2,pop2,no_of_objs_T2);
    [population_T2,~]=SolutionComparison.diversity(population_T2,frontnumbers,pop2,no_of_objs_T2);
    for i = 1:pop/2
        population_T1(i).rank = i;
        population_T2(i).rank = i;
    end
    population(1:pop1) = population_T1;
    population(pop1+1:pop) = population_T2;
    
    for generation=1:gen
        rndlist=randperm(pop);
        population=population(rndlist);
        for i = 1:pop
            parent(i)=Chromosome();
            p1=1+round(rand(1)*(pop-1));
            p2=1+round(rand(1)*(pop-1));
            if population(p1).rank < population(p2).rank
                parent(i).rnvec=population(p1).rnvec;
                parent(i).skill_factor=population(p1).skill_factor;
            elseif population(p1).rank == population(p2).rank
                if rand(1) <= 0.5
                    parent(i).rnvec=population(p1).rnvec;
                    parent(i).skill_factor=population(p1).skill_factor;
                else
                    parent(i).rnvec=population(p2).rnvec;
                    parent(i).skill_factor=population(p2).skill_factor;
                end
            else
                parent(i).rnvec=population(p2).rnvec;
                parent(i).skill_factor=population(p2).skill_factor;
            end
        end
        population_T3=parent([parent.skill_factor]==1);
        population_T4=parent([parent.skill_factor]==2);
        count=1;
        if mod(generation,G) ~= 0
            for i=1:2:pop-1
                child(count)=Chromosome;
                child(count+1)=Chromosome;
                p1=i;
                p2=i+1;
                if parent(p1).skill_factor==parent(p2).skill_factor
                    [child(count).rnvec,child(count+1).rnvec]=Evolve.crossover(parent(p1).rnvec,parent(p2).rnvec,muc,dim,pc);
                    child(count).rnvec = Evolve.mutate(child(count).rnvec,mum,dim,1/dim);
                    child(count+1).rnvec=Evolve.mutate(child(count+1).rnvec,mum,dim,1/dim);
                    child(count).skill_factor=parent(p1).skill_factor;
                    child(count+1).skill_factor=parent(p2).skill_factor;
                else
                    if rand(1)<rmp
                        [child(count).rnvec,child(count+1).rnvec]= Evolve.crossover(parent(p1).rnvec,parent(p2).rnvec,muc,dim,pc);
                        child(count).rnvec = Evolve.mutate(child(count).rnvec,mum,dim,1/dim);
                        child(count+1).rnvec=Evolve.mutate(child(count+1).rnvec,mum,dim,1/dim);
                        child(count).skill_factor=round(rand(1))+1;
                        child(count+1).skill_factor=round(rand(1))+1;
                    else
                        child(count).rnvec = Evolve.mutate(parent(p1).rnvec,mum,dim,1);
                        child(count+1).rnvec=Evolve.mutate(parent(p2).rnvec,mum,dim,1);
                        child(count).skill_factor=parent(p1).skill_factor;
                        child(count+1).skill_factor=parent(p2).skill_factor;
                    end
                end
                count=count+2;
            end
            charpp = [];
            for i = 1:pop
                if child(i).skill_factor == 1
                    charpp(end+1,1:dim)=child(i).rnvec;
                end
            end
        else
            child = Strategy(population);
            for i = 1:size(child)
                child(i).rnvec = Evolve.mutate(child(i).rnvec,mum,dim,1);
            end
        end
        for i=1:pop
            child(i)=evaluate(child(i),Task,dim1,dim2);
        end
        
        population=reset(population,pop);
        intpopulation(1:pop)=population;
        intpopulation(pop+1:2*pop)=child;
        intpopulation_T1=intpopulation([intpopulation.skill_factor]==1);
        intpopulation_T2=intpopulation([intpopulation.skill_factor]==2);
        T1_pop=length(intpopulation_T1);
        T2_pop=length(intpopulation_T2);
        pop_objs_T1=[];
        pop_objs_T2=[];
        for i=1:T1_pop
            pop_objs_T1(i,:) = intpopulation_T1(i).objs_T1;
        end
        [frontnumbers, FrontNO1,~] = NDSort(pop_objs_T1,inf);
        for i=1:T1_pop
            intpopulation_T1(i).front = FrontNO1(i);
        end
        [intpopulation_T1,~]=SolutionComparison.diversity(intpopulation_T1,frontnumbers,T1_pop,no_of_objs_T1);
        for i=1:T2_pop
            pop_objs_T2(i,:) = intpopulation_T2(i).objs_T2;
        end
        [frontnumbers, FrontNO2,~] = NDSort(pop_objs_T2,inf);
        for i=1:T2_pop
            intpopulation_T2(i).front = FrontNO2(i);
        end
        [intpopulation_T2,~]=SolutionComparison.diversity(intpopulation_T2,frontnumbers,T2_pop,no_of_objs_T2);
        population(1:pop1) = intpopulation_T1(1:pop1);
        population(pop1+1:pop) = intpopulation_T2(1:pop2);
        
        if index == 8 || index == 9
            T1_data = vec2mat([population(1:pop1).objs_T1],3);
            T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
        else
            T1_data = vec2mat([population(1:pop1).objs_T1],2);
            T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
        end
        store(1,generation)=cal_IGD(T1_data,Task.type1);
        store(2,generation)=cal_IGD(T2_data,Task.type2);
        store(1,generation)=min(store(1,:));
        store(2,generation)=min(store(2,:));
        disp(['Index = ',num2str(index),'   ', 'Generation = ',num2str(generation),'   ','MOMFEA IGD = ', num2str(store(1,generation)),'  ', num2str(store(2,generation))]);
    end
    IGD(1,rep) = store(1,gen);
    IGD(2,rep) = store(2,gen);
end
data_MOMFEA.wall_clock_time = toc;
data_MOMFEA.IGD = store;
end