function [obj,convio]=mo_benchmark(x,fun)

 D=length(x);
 convio=0;
%% CIHS
 % x1 �� [0, 1], xi �� [?100, 100], i = 2, 3, . . . , n 
 % decision variables n is set to 50 for both T1 and T2
 % CIHS_task_T1
 if strcmp(fun,'CIHS_task_T1') 
    q =0;
    for i =2:D
        q = q + x(i)^2;
    end
    q = q + 1;
    obj(1) = q * cos(pi*x(1)/2);
    obj(2) = q * sin(pi*x(1)/2);
end
 % CIHS_task_T2
if strcmp(fun,'CIHS_task_T2') 
    var_var =0;
    for i=2:D
        var_var = var_var + abs(x(i));
    end
    q = 1 + (9/(D-1))*var_var;
    obj(1) = x(1);
    obj(2) = q*(1-(x(1)/q)^2);
end
%% CIMS
% x1 �� [0, 1], xi �� [-5, 5], i = 2, 3, . . . , n
% decision variables n is set to 10 for both T1 and T2
% CIMS_task_T1
if strcmp(fun,'CIMS_task_T1') 
    q =0;
    for i=2:D-1
        q = q + (100*(x(i)^2 - x(i+1)))^2 + (1-x(i))^2;
    end
    q = q +1;
    obj(1) = x(1);
    obj(2) = q*(1-(x(1)/q)^2);
end
% CIMS_task_T2
if strcmp(fun,'CIMS_task_T2') 
    load S_CIMS_2.txt
    load M_CIMS_2.txt
    cm = x(1,2:D);
    z = (M_CIMS_2*(cm' - S_CIMS_2))';
    var_var =0;
    for i = 1:D-1
        var_var = var_var + abs(z(i));
    end
    q = 1 + (9/(D-1))*var_var;
    obj(1) = q * cos(pi*x(1)/2);
    obj(2) = q * sin(pi*x(1)/2);
end
%% CILS
% decision variables n is set to 50 for both T1 and T2
% CILS_task_T1
% x1 �� [0, 1], xi �� [-2, 2], i = 2, 3, . . . , n
if strcmp(fun,'CILS_task_T1') 
    q = 0;
    for i = 2:D
        q = q + (x(i)^2 - 10*cos(2*pi*x(i)) + 10);
    end
    q = q+1;
    obj(1) = q * cos(pi*x(1)/2);
    obj(2) = q * sin(pi*x(1)/2);
end
% CILS_task_T2
% x1 �� [0, 1], xi �� [-1, 1], i = 2, 3, . . . , n
if strcmp(fun,'CILS_task_T2') 
    var_var = 0;
    var_cos = 0;
    for i=2:D
        var_var = var_var + x(i)^2;
        var_cos = var_cos + cos(2*pi*x(i));
    end
    q = 21+ exp(1) - 20*exp(-0.2*sqrt((1/(D-1))*var_var)) - exp((1/(D-1))*var_cos);
    obj(1) = x(1);
    obj(2) = q * (1-sqrt(x(1)/q));
end
%% PIHS
% decision variables n is set to 50 for both T1 and T2
% PIHS_task_T1
% x1 �� [0, 1], xi �� [-100, 100], i = 2, 3, . . . , n
if strcmp(fun,'PIHS_task_T1') 
    q = 0;
    for i=2:D
        q = q+x(i)^2;
    end
    q = q + 1;
    obj(1) = x(1);
    obj(2) = q * (1-sqrt(x(1)/q));
end
% PIHS_task_T2
% x1 �� [0, 1], xi �� [-100, 100], i = 2, 3, . . . , n
if strcmp(fun,'PIHS_task_T2') 
    load S_PIHS_2.txt
    cm = x(1,2:D);
    z = (cm'-S_PIHS_2)';
    q = 0;
    for i = 1:D-1
        q = q + (z(i)^2 - 10*cos(2*pi*z(i)) + 10);
    end
    q = q +1;
    obj(1) = x(1);
    obj(2) = q * (1-sqrt(x(1)/q));
end
%% PIMS
% decision variables n is set to 50 for both T1 and T2
% PIMS_task_T1
% xi �� [0, 1], i = 1, 2, 3, . . . , n
if strcmp(fun,'PIMS_task_T1') 
    load M_PIMS_1.txt
    load S_PIMS_1.txt
    cm = x(1,2:D);
    z = (M_PIMS_1*(cm'-S_PIMS_1))';
    q = 0;
    for i=1:D-1
        q = q + z(i)^2;
    end
    q = q + 1;
    obj(1) = q * cos(pi*x(1)/2);
    obj(2) = q * sin(pi*x(1)/2);
end
% PIMS_task_T2
% xi �� [0, 1], i = 1, 2, 3, . . . , n
if strcmp(fun,'PIMS_task_T2') 
    load M_PIMS_2.txt 
    cm = x(1,2:D);
    z = (M_PIMS_2*cm')'; 
    q = 0;
    for i = 1:D-1
         q = q + (z(i)^2 - 10*cos(2*pi*z(i)) + 10);
    end
    q = q + 1;
    obj(1) = x(1);
    obj(2) = q * (1-(x(1)/q)^2);
end
%% PILS
%  decision variables n is set to 50 for both T1 and T2
% PILS_task_T1
% x1 �� [0, 1], xi �� [-50, 50], i = 2, 3, . . . , n
if strcmp(fun,'PILS_task_T1') 
    var_var = 0;
    var_cos = 1;
    for i=2:D
        var_var = var_var + x(i)^2;
        var_cos = var_cos * cos(x(i)/sqrt(i-1));
    end
    q = 2+(1/4000)*var_var-var_cos;
    obj(1) = q * cos(pi*x(1)/2);
    obj(2) = q * sin(pi*x(1)/2);
end
% PILS_task_T2
% x1 �� [0, 1], xi �� [-100, 100], i = 2, 3, . . . , n
if strcmp(fun,'PILS_task_T2') 
    load S_PILS_2.txt
    cm = x(1,2:D);
    z = (cm'-S_PILS_2)';
    var_var = 0;
    var_cos = 0;
    for i=1:D-1
        var_var = var_var + z(i)^2;
        var_cos = var_cos + cos(2*pi*z(i));
    end
    q = 21+exp(1)-20*exp(-0.2*sqrt((1/(D-1))*var_var))-exp((1/(D-1))*var_cos);
    obj(1) = q * cos(pi*x(1)/2);
    obj(2) = q * sin(pi*x(1)/2);
end
%% NIHS
% decision variables n is set to 50 for both T1 and T2
% NIHS_task_T1
% xi �� [0, 1], xi �� [-80, 80], i = 2, 3, . . . , n
if strcmp(fun,'NIHS_task_T1') 
   q = 0;
    for i=2:D-1
        q = q + (100*(x(i)^2-x(i+1))^2 + (1-x(i))^2);
    end
    q = q+1;
    obj(1) = q * cos(pi*x(1)/2);
    obj(2) = q * sin(pi*x(1)/2);
end
% NIHS_task_T2
% x1 �� [0, 1], xi �� [-80, 80], i = 2, 3, . . . , n
if strcmp(fun,'NIHS_task_T2') 
    q = 0;
    for i=2:D
        q = q + x(i)^2;
    end
    q = q +1;
    obj(1) = x(1);
    obj(2) = q * (1 - sqrt(x(1)/q));
end
%% NIMS
% decision variables n is set to 20 for both T1 and T2
% NIMS_task_T1
% x1 �� [0, 1], x2 �� [0, 1], xi �� [-20, 20], i = 3, 4, . . . , n
if strcmp(fun,'NIMS_task_T1') 
    q =0;
    for i=3:D-1
        q = q+(100*(x(i)^2 - x(i+1))^2+(1-x(i))^2);
    end
    q = 1 + q;
    obj(1) = q * cos(pi*x(1)/2)* cos(pi*x(2)/2);
    obj(2) = q * cos(pi*x(1)/2)* sin(pi*x(2)/2);
    obj(3) = q * sin(pi*x(1)/2);
end
% NIMS_task_T2
% x1 �� [0, 1], x2 �� [0, 1], xi �� [-20, 20], i = 3, 4, . . . , n
if strcmp(fun,'NIMS_task_T2') 
    load M_NIMS_2.txt
    cm = x(1,3:D);
    z = (M_NIMS_2*cm')';
    q = 0;
    for i=1:D-2
        q = q+z(i)^2;
    end
    q = q +1;
    obj(1) = (x(1)+x(2))/2;
    obj(2) = q* (1-((x(1)+x(2))/(2*q))^2);
end
%% NILS
% decision variables n is set to 25 for T1 and 50 for T2
% NILS_task_T1
% x1 �� [0, 1], x2 �� [0, 1], xi �� [-50, 50], i = 3, 4, . . . , n
if strcmp(fun,'NILS_task_T1') 
     load S_NILS_1.txt
    cm = x(1,3:D);
    z = (cm'-S_NILS_1)';
    var_var = 0;
    var_cos = 1;
    for i=1:D-2
        var_var = var_var + z(i)^2;
        var_cos = var_cos * cos(z(i)/sqrt(i));
    end
    q = 2 + (1/4000)*var_var - var_cos; 
    obj(1) = q * cos(pi*x(1)/2)* cos(pi*x(2)/2);
    obj(2) = q * cos(pi*x(1)/2)* sin(pi*x(2)/2);
    obj(3) = q * sin(pi*x(1)/2);
end
% NILS_task_T2
% x1 �� [0, 1], x2 �� [0, 1], xi �� [-100, 100], i = 3, 4, . . . ,
if strcmp(fun,'NILS_task_T2') 
     var_var = 0;
     var_cos = 0;
     for i=3:D
        var_var = var_var + x(i)^2;
        var_cos = var_cos + cos(2*pi*x(i));
     end
     q = 21+exp(1)-20*exp(-0.2*sqrt((1/(D-2))*var_var))-exp((1/(D-2))*var_cos);
     obj(1) = (x(1)+x(2))/2;
     obj(2) = q * (1-((x(1)+x(2))/(2*q))^2);
end
end