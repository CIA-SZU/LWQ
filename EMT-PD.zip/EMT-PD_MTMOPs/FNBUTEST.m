pop = 100000;
dim = 100;
for i=1:pop
    population(i)=Chromosome;
    population(i)=initialize(population(i),dim);
    population(i).skill_factor=1;

end

for i=1:pop
    population(i)=evaluate(population(i),Task,12,30);
end